package com.uas.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.CustomException;
import com.uas.service.AdminService;

public class AdminController 
{
	private static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) throws CustomException 
	{
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		boolean isInProcess=true;
		
		
		byte choice=0;
		
		String programName=null; //primary key
		String description=null;
		String applicantEligibility=null;
		byte duration=0;
		String degreeOffered=null;
		
		Scanner sc=new Scanner(System.in);
		
		AdminService serviceAdmin=new AdminService();
		
		ProgramsOfferedBean programsOfferedBean=null;
		List<ApplicantBean>applicantList = null;
		//ProgramsScheduledBean programsScheduledBean=null;
		List<ProgramsScheduledBean>programsScheduledList = null;
		
		while(isInProcess)
		{
			System.out.println("1) Insert Programs Offered");
			System.out.println("2) Delete Programs Offered");
			System.out.println("3) Select list of applicants");
			System.out.println("4) Delete Programs Scheduled");
			System.out.println("5) Select Programs Scheduled");
			System.out.println("6) Insert Programs Scheduled");
			System.out.println("0) Exit");
			
         choice=Byte.parseByte(sc.nextLine());
			
			switch(choice){
			case 1:
		
				System.out.println("Enter program name: ");
				programName=sc.nextLine();
				System.out.println("Enter description: ");
				description=sc.nextLine();
				System.out.println("Enter applicant eligibility: ");
				applicantEligibility=sc.nextLine();
				System.out.println("Enter duration: ");
				duration=Byte.parseByte(sc.nextLine());
				System.out.println("Enter degree offered: ");
				degreeOffered=sc.nextLine();
				
				
				programsOfferedBean=new ProgramsOfferedBean(programName,description,applicantEligibility,duration,degreeOffered);
				try{
					boolean isInserted=serviceAdmin.addProgramOffered(programsOfferedBean);
					
					if(isInserted)
						System.out.println("Inserted Successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 2:
				System.out.println("Enter program name: ");
				String programNam=sc.nextLine();
				
				try{
					boolean isDeleted=serviceAdmin.deleteProgramOffered(programNam);
					
					if(isDeleted)
						System.out.println("Deleted successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
			case 3:
				try{
					applicantList = serviceAdmin.viewListOfApplicants();
						for (ApplicantBean bean : applicantList){
							System.out.println(bean);
						}
						System.out.println("====================================================================");
					}catch(CustomException e){
						throw  new CustomException("coudnt retrive list"+e.getMessage());
					}
					break;
			case 4:
			
				System.out.println("Enter program id: ");
				String progId=sc.nextLine();
				
				try{
					boolean isDeleted=serviceAdmin.deleteProgramScheduled(progId);
					
					if(isDeleted)
						System.out.println("Deleted successfully!");
					
				}catch(CustomException e){
					logger.error(e.getMessage());
				}
				
				break;
				
			case 5:
				try{
					programsScheduledList = serviceAdmin.viewProgramsScheduled();
						for (ProgramsScheduledBean programsScheduledBean : programsScheduledList){
							System.out.println(programsScheduledBean);
						}
						System.out.println("====================================================================");
					}catch(CustomException e){
						throw new CustomException("list not found"+e.getMessage());
					}
					break;
		
			case 6:
				try{
					
					
					final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy");
					ProgramsScheduledBean bean = new ProgramsScheduledBean();
					System.out.println("Enter program id");
					bean.setProgramId(sc.nextLine());
					
					
					System.out.println("Enter program name");
					bean.setProgramName(sc.nextLine());
					
					System.out.println("Enter program city");
					bean.setCity(sc.nextLine());
					
					System.out.println("Enter program state");
					bean.setState(sc.nextLine());
					
					System.out.println("Enter program start date in format MM/dd/yyyy");
					
					LocalDate sDate = LocalDate.parse(sc.nextLine(),dtf);
					bean.setStartDate(sDate);
					
					System.out.println("Enter program end date in format MM/dd/yyyy");
					LocalDate eDate = LocalDate.parse(sc.nextLine(),dtf);
					bean.setEndDate(eDate);
					
					System.out.println("Enter program zipcode");
					bean.setZipCode(sc.nextInt());
					
					
					
					
					System.out.println("Enter program sessions per week");
					bean.setSessionPerWeek(sc.nextByte());
					
					boolean isInserted = serviceAdmin.addProgramScheduled(bean);
					if(isInserted == true){
						System.out.println("Record inserted successfully");
					}else{
						System.out.println("couldnt enter record");
					}
					
				}catch(CustomException e){
					throw new CustomException("record not entered"+e.getMessage());
				}
           case 0:
				
				isInProcess=false;
				break;
				
			default:
				
				System.out.println("Invalid input");
				logger.error("Invalid input: "+choice);
				System.err.println("Invalid input: "+choice);
				break;
	}
}
		sc.close();
}
}