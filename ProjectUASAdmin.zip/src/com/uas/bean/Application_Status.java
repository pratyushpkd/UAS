package com.uas.bean;

public enum Application_Status{
	applied, rejected, confirmed, accepted;
}
