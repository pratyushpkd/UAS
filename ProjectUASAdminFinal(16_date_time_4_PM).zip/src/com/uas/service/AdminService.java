package com.uas.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserRole;
import com.uas.dao.AdminDAOImpl;
import com.uas.dao.IAdminDAO;
import com.uas.exception.CustomException;

public class AdminService implements IAdminService {

	private IAdminDAO adminDAO;

	public AdminService() {
		adminDAO = new AdminDAOImpl();
	}

	@Override
	public boolean isAuthenticated(String loginId, String pass, UserRole role)
			throws CustomException {
		
		return adminDAO.isAuthenticated(loginId, pass, role);
	}
	

	@Override
	public boolean deleteProgramOffered(String programName)
			throws CustomException {
		return adminDAO.deleteProgramOffered(programName);
	}

	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws CustomException {

		return adminDAO.addProgramOffered(programsOfferedBean);
	}

	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws CustomException {

		return adminDAO.viewProgramsScheduled();
	}

	@Override
	public boolean deleteProgramScheduled(String programId)
			throws CustomException {

		return adminDAO.deleteProgramScheduled(programId);
	}

	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws CustomException {

		return adminDAO.addProgramScheduled(programsScheduledBean);
	}

	@Override
	public List<ApplicantBean> viewListOfApplicants() throws CustomException {

		return adminDAO.viewListOfApplicants();
		/*
		 * List<ApplicantBean> applicantList=adminDAO.viewListOfApplicants();
		 * return applicantList;
		 */

	}


	public boolean isValidProgramName(String programName)
			throws CustomException {
		boolean isValid = false;

		String regx = "^[\\p{L} .'-]+$";


		Pattern pattern = Pattern.compile(regx,Pattern.UNICODE_CASE);
	    Matcher matcher = pattern.matcher(programName);
		isValid = matcher.matches();

		if (!isValid) {
			throw new CustomException(
					"Name must start with Capital and must contains only letters");
		}
		return isValid;
	}
	
	public boolean isValidDescription(String description)
			throws CustomException {
		boolean isValid = false;

		if(description.length() <= 200){
			isValid = true;
			
		}

		if (!isValid) {
			throw new CustomException(
					"Exceeding the limit more than 200 char");
		}
		return isValid;
	}
	
	public boolean isValidEligibility(String applicantEligibility)
			throws CustomException {
		boolean isValid = false;

		if(applicantEligibility.length() <= 100){
			isValid = true;
			
		}

		if (!isValid) {
			throw new CustomException(
					"Exceeding the limit more than 100 char");
		}
		return isValid;
	}
	
	public boolean isValidDuration(byte duration) throws CustomException{
		boolean isValid = false;
			String dura = Byte.toString(duration);
			String pattern ="[1-9]{1}[0-9]{0,1}[0-9]{0,1}";
		  
		  Pattern ptn = Pattern.compile(pattern);
		  Matcher matcher = ptn.matcher(dura);
		  isValid = matcher.matches();
		  
		  if (!isValid) {
				throw new CustomException(
						"Duration cannot be negative! kindly, enter again.");
			}
		
		return isValid;
	}
	
	public boolean isValidDegreeOffered(String degreeOffered)
			throws CustomException {
		boolean isValid = false;

		if(degreeOffered.length() <= 30){
			isValid = true;
			
		}

		if (!isValid) {
			throw new CustomException(
					"Exceeding the DEGREE_CERTIFICATE_OFFERED limit more than 30 char");
		}
		return isValid;
	}
	
	public boolean checkValidProgramId(String programId) throws CustomException{
		boolean isValid = false;
			
			String pattern ="[A-Z]{2}[0-9]{0,3}";
		  
		  Pattern ptn = Pattern.compile(pattern);
		  Matcher matcher = ptn.matcher(programId);
		  isValid = matcher.matches();
		
		  if (!isValid) {
				throw new CustomException(
						"Name must start with Capital and must contains only letters");
			}
			
		return isValid;
	}
	
	public boolean checkValidCity(String city) throws CustomException{
		boolean isValid = false;

		String regx = "^[\\p{L} .'-]+$";


		Pattern pattern = Pattern.compile(regx,Pattern.UNICODE_CASE);
	    Matcher matcher = pattern.matcher(city);
		isValid = matcher.matches();

		if (!isValid) {
			throw new CustomException(
					"city must start with Capital and must contains only letters");
		}
		return isValid;
	}
	public boolean checkValidState(String state) throws CustomException{
		boolean isValid = false;

		String regx = "^[\\p{L} .'-]+$"; 


		Pattern pattern = Pattern.compile(regx,Pattern.UNICODE_CASE);
	    Matcher matcher = pattern.matcher(state);
		isValid = matcher.matches();

		if (!isValid) {
			throw new CustomException(
					"state must start with Capital and must contains only letters");
		}
		return isValid;
	}
/*	public boolean checkValidStartDate(LocalDate startDate) throws CustomException{
		boolean isValid = false;
		//String dura = Byte.toString(duration);
		String date = startDate.toString();	
		String pattern ="^(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.]((19|20)\\d\\d)$";
		  
		  Pattern ptn = Pattern.compile(pattern);
		  Matcher matcher = ptn.matcher(date);
		  isValid = matcher.matches();
		
		return isValid;
	}
	*/
	
	public boolean checkValidZipcode(int zipCode)
			throws CustomException {
		boolean isValid = false;
		String zip = Integer.toString(zipCode) ;
		if(zip.length() == 6){
			isValid = true;
			
		}

		if (!isValid) {
			throw new CustomException(
					"Zipcode cannot be more or less than 6 digits");
		}
		return isValid;
	}

	
	
}
