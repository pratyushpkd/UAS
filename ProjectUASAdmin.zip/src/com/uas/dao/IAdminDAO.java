package com.uas.dao;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserRole;
import com.uas.exception.CustomException;

public interface IAdminDAO {
	public boolean isAuthenticated(String loginId, String pass) throws CustomException;
	
	//Programs Offered Features
	public boolean deleteProgramOffered(String programName) throws CustomException;
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean) throws CustomException;
	
	//Programs Offered Features
	public List<ProgramsScheduledBean> viewProgramsScheduled() throws CustomException;
	public boolean deleteProgramScheduled(String programId) throws CustomException;
	public boolean addProgramScheduled(ProgramsScheduledBean programsScheduledBean) throws CustomException;
	
	//view applicant for status
	public List<ApplicantBean> viewListOfApplicants() throws CustomException;
}
