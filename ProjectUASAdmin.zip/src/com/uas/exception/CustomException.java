package com.uas.exception;

public class CustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5204212987634324898L;

	public CustomException(String message) {
		super(message);
	}
	
}
