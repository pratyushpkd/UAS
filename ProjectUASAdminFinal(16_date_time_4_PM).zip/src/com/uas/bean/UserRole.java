package com.uas.bean;

public enum UserRole{
	admin, mac;	
}
